

import io.indico.Indico;
import io.indico.api.results.IndicoResult;
import io.indico.api.utils.IndicoException;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.File;
import java.text.Normalizer;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.List;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import io.indico.Indico;
import java.io.*;
import io.indico.api.results.IndicoResult;
import io.indico.api.utils.IndicoException;
import java.io.IOException;
import java.text.Normalizer.Form;


public class Twitter_score {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException,TwitterException,IndicoException, UnsupportedOperationException {
    
        ConfigurationBuilder cb = new ConfigurationBuilder();
           cb.setDebugEnabled(true)
                   .setOAuthConsumerKey("gjlAuab8pCpSLauXgabhKAL7K")
                   .setOAuthConsumerSecret("MxbczOJwOzCNlumvVDHEGmIgihx2EohisTylO8Shv71YPlBomA")
                   .setOAuthAccessToken("193860711-GDQQOuIAnDKkViqwMiJ3PukPrKxIHHpGYlHsS1tB")
                   .setOAuthAccessTokenSecret("sA1uv8xY2qBjIBCQZYbz5o97URZlHvd5ma3ClhKmUDXbp");
         Twitter twitter = TwitterFactory.getSingleton();
   /* List<Status> statuses = twitter.getHomeTimeline();
    System.out.println("Showing home timeline.");
    for (Status status : statuses) {
        System.out.println(status.getUser().getName() + ":" +
                           status.getText());
    }*/
         System.out.println( "*******************************************");
         System.out.println( "      Twitter Sentiment ANALYSIS           ");
         System.out.println( "*******************************************");
    TwitterFactory tf= new TwitterFactory(cb.build());
    twitter4j.Twitter tw=tf.getInstance();
    
    
   /* List<Status> statuses = tw.getHomeTimeline();
    System.out.println("Showing home timeline.");
    for (Status status : statuses) {
        System.out.println(status.getUser().getName() + ":" +
                           status.getText());}*/
    
 /*  Query query = new Query("#Paris");
   query.setCount(100);
    QueryResult result = tw.search(query);
    for (Status status : result.getTweets()) {
        System.out.println("@" + status.getUser().getScreenName() + ":" + status.getText());
    }*/
  int t=0;
  Scanner in1 = new Scanner(System.in);
  System.out.println("1.Enter 1 for extract data from Live Twitter and get sentiment for Tweets");
  System.out.println("2.Enter 2 for Upload file and get Sentiment for Tweets");
  t = in1.nextInt();
    if(t==1){
   BufferedWriter writer = null;
        try {
            //create a temporary file
            String timeLog = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
            File logFile = new File(timeLog);
             Scanner in2 = new Scanner(System.in);
      String s2;
      System.out.println("Enter a Keyword to serach for Tweets Live");
      s2 = in2.nextLine();
      System.out.println("Sentiment are given between 0-10");
 
            // This will output the full path where the file will be written to...
         //   System.out.println(logFile.getCanonicalPath());
            Indico indico2 = new Indico("43a539720431b9b0d8a3c312a6202bcf");

            writer = new BufferedWriter(new FileWriter(logFile));
             Query query = new Query(s2);
           query.setCount(100);
    QueryResult result = tw.search(query);
    for (Status status : result.getTweets()) {
       String s=status.getText();
       s=removeDiacriticalMarks(s);
         //      System.out.println(s);
       IndicoResult single = indico2.sentiment.predict(s);
Double result1 = single.getSentiment()*10;
System.out.println(s+","+result1);
//     System.out.println(s);
       // writer.write("@" + status.getUser().getScreenName() + ":" + status.getText()+"/n");
    
        } }catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Done");
        } finally {
            try {
                // Close the writer regardless of what happens...
                writer.close();
            } catch (Exception e) {
            }
        }}else if(t==2){
    
   //   ----------------------------------------------------------  
    Writer output = null;
    String text = "";  
    String strLine=" ";
    try{
  // Open the file that is the first 
  // command line parameter
      String s2;
       Scanner in3 = new Scanner(System.in);
      System.out.println("Enter a File Name with Tweets to assign sentiments ");
      s2 = in3.nextLine();
      System.out.println("Sentiment are given between 0-10");     
  FileInputStream fstream = new FileInputStream("C:\\Users\\manju\\Desktop\\"+s2);
  // Get the object of DataInputStream
  DataInputStream in = new DataInputStream(fstream);
  BufferedReader br = new BufferedReader(new InputStreamReader(in));
 
  
  File file = new File("C:\\Users\\manju\\Desktop\\write.txt");
  output = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
  Indico indico2 = new Indico("43a539720431b9b0d8a3c312a6202bcf");
  //Read File Line By Line
  IndicoResult single;
Double result1;
output.flush();
int count=0;
  while ((strLine = br.readLine()) != null)   {
  // Print the content on the console
 // System.out.println (strLine);
  single = indico2.sentiment.predict(strLine);
  result1 = single.getSentiment();
  int t1=(int) (result1*10);
  count=count+1;
  text="a"+count+","+t1;
 // System.out.println(text);
  //output.append('\n');
  output.write(System.getProperty( "line.separator" ));
  output.append(text);
   }
  //Close the input stream
  in.close();
  output.close();
  System.out.println("Sentiments are written to file Write.txt");
    }catch (Exception e){//Catch exception if any
         if(e.getMessage().equals("Input contains one or more empty strings")){
  System.out.println("Sentiments are written to file Write.txt");           
         }else{
  System.err.println("Sentiments are written to file Write.txt");}
  }
        }
  }
    public static String removeDiacriticalMarks(String string) {
    return Normalizer.normalize(string, Form.NFD)
        .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
}
}

    

    
    

